import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Proof from "./components/Proof";
import Guide from "./components/Guide";
import Testimonials from "./components/Testimonials";
import Price from "./components/Price";
import FAQ from "./components/FAQ";
import FinalCTA from "./components/FinalCTA";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="relative min-h-screen bg-[#06060A] text-white overflow-x-hidden">
      <Navbar />
      <main>
        <Hero />
        <Proof />
        <Guide />
        <Testimonials />
        <Price />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
