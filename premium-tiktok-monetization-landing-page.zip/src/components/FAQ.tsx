import { useState } from "react";
import { Reveal } from "./Reveal";
import { Plus, Minus, MessageCircle } from "lucide-react";

const faqs = [
  {
    q: "Mon pays n'est pas dans la liste officielle de Creator Rewards. À quoi sert le guide ?",
    a: "À trois choses. D'abord, à vérifier que c'est bien la seule ligne en rouge : sur la plupart des comptes que les lecteurs nous montrent, d'autres critères que vous contrôlez bloquent aussi (avertissements, vidéos trop courtes, reposts, mauvais type de compte). Ensuite, à mettre votre compte 100 % en règle pour être prêt le jour où votre pays est ajouté, sans devoir tout refaire. Enfin, à activer ce qui est déjà possible chez vous aujourd'hui : le LIVE et ses cadeaux, les partenariats avec des marques locales, la vente de vos propres produits. Le guide dit clairement ce qui est possible pays par pays, sans VPN ni fausse localisation, car ces méthodes font bannir les comptes.",
  },
  {
    q: "Comment payer et recevoir le guide ?",
    a: "Vous cliquez sur le bouton, vous choisissez votre opérateur (MTN MoMo, Moov Money, Orange Money, Wave ou Free Money), vous entrez votre numéro et vous validez avec votre code secret. Dès que le paiement est confirmé, le lien de téléchargement arrive sur votre WhatsApp et votre e-mail, en général en moins de 5 minutes. Si vous n'avez rien reçu après 30 minutes, écrivez-nous sur WhatsApp avec votre numéro de transaction : on vous renvoie le lien à la main. Pour la diaspora, le paiement par carte bancaire est aussi possible.",
  },
  {
    q: "Je débute avec moins de 1 000 abonnés. Est-ce que c'est pour moi ?",
    a: "Oui. C'est même moins cher de bien commencer que de réparer plus tard. Le guide vous fait choisir le bon type de compte, publier dès le début des vidéos qui comptent pour l'éligibilité, et éviter les trois erreurs qui valent des avertissements aux débutants : reposts, sons non autorisés, achat d'abonnés. Vous atteindrez les seuils moins vite qu'un compte déjà lancé, mais vous n'aurez rien à défaire.",
  },
  {
    q: "Et si le guide ne m'apprend rien ?",
    a: "Vous avez 7 jours pour le lire. Si vous estimez qu'il ne vous a rien appris, envoyez un message sur WhatsApp avec votre numéro de transaction : vous êtes remboursé de 1 000 FCFA sur le même Mobile Money sous 72 heures, sans justification à donner. Une précision honnête : le guide ne garantit ni l'éligibilité ni un revenu, car cela dépend de votre pays, de votre régularité et des règles de TikTok, qui changent. Il garantit que vous saurez exactement quoi corriger, et dans quel ordre.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-20 sm:py-28 scroll-mt-24">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="text-center mb-12">
            <span className="inline-block text-xs uppercase tracking-[0.3em] text-[#25F4EE] mb-4">Questions fréquentes</span>
            <h2 className="text-4xl sm:text-5xl font-bold tracking-[-0.03em]">
              Quatre questions, <span className="font-serif italic gradient-text">quatre vraies réponses.</span>
            </h2>
          </div>
        </Reveal>

        <div className="space-y-3">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={i} delay={i * 60}>
                <div
                  className={`rounded-2xl glass border transition-all duration-500 overflow-hidden ${
                    isOpen ? "border-white/20 bg-white/[0.05]" : "border-white/10 hover:border-white/15"
                  }`}
                >
                  <button
                    onClick={() => setOpen(isOpen ? null : i)}
                    className="w-full flex items-center justify-between gap-4 p-5 sm:p-6 text-left"
                    aria-expanded={isOpen}
                    aria-controls={`faq-panel-${i}`}
                    id={`faq-button-${i}`}
                  >
                    <span className="font-semibold text-base sm:text-lg tracking-tight">{f.q}</span>
                    <div
                      className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                        isOpen ? "bg-gradient-to-br from-[#FE2C55] to-[#FF4D7A] rotate-180" : "bg-white/5 border border-white/10"
                      }`}
                    >
                      {isOpen ? <Minus className="w-4 h-4" strokeWidth={2.5} /> : <Plus className="w-4 h-4" strokeWidth={2.5} />}
                    </div>
                  </button>
                  <div
                    id={`faq-panel-${i}`}
                    role="region"
                    aria-labelledby={`faq-button-${i}`}
                    className="grid transition-all duration-500 ease-out"
                    style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                  >
                    <div className="overflow-hidden">
                      <div className="px-5 sm:px-6 pb-6 text-white/70 leading-relaxed">{f.a}</div>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={200}>
          <div className="mt-8 p-5 rounded-2xl glass border border-white/10 text-center text-sm">
            <span className="text-white/60">Autre question ? </span>
            <a href="#" className="inline-flex items-center gap-1.5 font-semibold text-[#25F4EE] hover:underline">
              <MessageCircle className="w-4 h-4" />
              Écrivez-nous sur WhatsApp
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
