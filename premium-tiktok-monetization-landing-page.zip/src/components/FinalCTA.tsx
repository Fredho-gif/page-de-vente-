import { Reveal } from "./Reveal";
import { ArrowRight, ShieldCheck, Smartphone, MessageCircle } from "lucide-react";
import { editionLabel } from "../utils/dates";

export default function FinalCTA() {
  return (
    <section className="relative py-20 sm:py-28 overflow-hidden">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="relative rounded-[2.5rem] overflow-hidden p-8 sm:p-14 lg:p-16 border border-white/10">
            <div className="absolute inset-0 -z-10">
              <div className="absolute inset-0 bg-gradient-to-br from-[#FE2C55] via-purple-800 to-[#25F4EE]" />
              <div
                className="absolute inset-0 opacity-20"
                style={{
                  backgroundImage:
                    "radial-gradient(circle at 20% 30%, rgba(255,255,255,0.4) 0%, transparent 40%), radial-gradient(circle at 80% 70%, rgba(255,255,255,0.3) 0%, transparent 40%)",
                }}
              />
              <div
                className="absolute inset-0 opacity-30 mix-blend-overlay"
                style={{
                  backgroundImage:
                    "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
                }}
              />
              <div className="absolute -top-20 -left-20 w-80 h-80 rounded-full bg-white/20 blur-3xl animate-float-slow" />
              <div className="absolute -bottom-20 -right-20 w-80 h-80 rounded-full bg-black/20 blur-3xl animate-float" />
            </div>

            <div className="relative text-center max-w-2xl mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20 mb-6 text-xs sm:text-sm">
                Guide PDF · Édition {editionLabel()}
              </div>

              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-[-0.03em] mb-5 leading-[1.05]">
                Arrêtez de deviner pourquoi TikTok <span className="font-serif italic">vous dit non.</span>
              </h2>
              <p className="text-lg sm:text-xl text-white/85 mb-8 leading-relaxed">
                40 minutes de lecture. Une checklist. Et vous savez enfin quoi corriger, dans quel ordre.
              </p>

              <a
                href="#prix"
                className="group inline-flex items-center justify-center gap-2 bg-white text-black px-8 py-4 rounded-2xl font-semibold text-base shadow-2xl hover:scale-105 transition-transform duration-300 mb-8"
              >
                Recevoir le guide · 1 000 FCFA
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>

              <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-white/85">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4" />
                  <span>Mobile Money</span>
                </div>
                <div className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4" />
                  <span>Envoyé sur WhatsApp</span>
                </div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Remboursé sous 7 jours si inutile</span>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
