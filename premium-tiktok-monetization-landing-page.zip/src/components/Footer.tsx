import { BadgeCheck, MessageCircle, Mail } from "lucide-react";
import { currentYear } from "../utils/dates";

const links = [
  { label: "Dans le guide", href: "#contenu" },
  { label: "Avis", href: "#avis" },
  { label: "Prix", href: "#prix" },
  { label: "FAQ", href: "#faq" },
  { label: "Remboursement", href: "#faq" },
  { label: "Confidentialité", href: "#" },
  { label: "CGV", href: "#" },
];

export default function Footer() {
  return (
    <footer className="relative border-t border-white/10 pt-12 pb-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-8 mb-10">
          <div className="max-w-sm">
            <a href="#" className="flex items-center gap-2.5 mb-4" aria-label="Guide Éligibilité TikTok — accueil">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#FE2C55] via-[#FF4D7A] to-[#25F4EE] flex items-center justify-center">
                <BadgeCheck className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex flex-col leading-none">
                <span className="font-bold text-[15px] tracking-tight">Guide Éligibilité</span>
                <span className="text-[10px] text-white/50 tracking-widest uppercase">TikTok · Afrique</span>
              </div>
            </a>
            <p className="text-white/50 text-sm leading-relaxed mb-4">
              Un guide simple pour comprendre pourquoi votre compte TikTok est « non éligible » et le corriger,
              depuis l'Afrique francophone. Sans triche, sans promesse de gains.
            </p>
            <div className="flex flex-col gap-2 text-sm text-white/60">
              <a href="#" className="inline-flex items-center gap-2 hover:text-white transition-colors">
                <MessageCircle className="w-4 h-4 text-[#25F4EE]" />
                Support WhatsApp · lun–sam, 9 h–19 h GMT
              </a>
              <a href="mailto:bonjour@guide-eligible.com" className="inline-flex items-center gap-2 hover:text-white transition-colors">
                <Mail className="w-4 h-4 text-[#25F4EE]" />
                bonjour@guide-eligible.com
              </a>
            </div>
          </div>

          <nav aria-label="Liens du pied de page" className="grid grid-cols-2 sm:grid-cols-3 gap-x-10 gap-y-3">
            {links.map((l) => (
              <a key={l.label} href={l.href} className="text-sm text-white/50 hover:text-white transition-colors">
                {l.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="pt-6 border-t border-white/10 flex flex-col gap-3">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-white/40">
            <span>© {currentYear()} Guide Éligibilité TikTok. Cotonou · Abidjan · Dakar.</span>
            <span>Prix en francs CFA (XOF / XAF)</span>
          </div>
          <p className="text-[11px] text-white/30 leading-relaxed max-w-3xl">
            Guide indépendant, non affilié à TikTok ni à ByteDance Ltd. Les critères d'éligibilité et la liste des pays
            couverts sont fixés par TikTok et peuvent changer sans préavis. Les résultats cités sont ceux de lecteurs
            individuels et ne constituent ni une garantie ni une promesse de revenus.
          </p>
        </div>
      </div>
    </footer>
  );
}
