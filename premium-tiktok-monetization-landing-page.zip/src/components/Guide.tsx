import { Reveal } from "./Reveal";
import { FileText, Smartphone, WifiOff, RefreshCw, ArrowRight } from "lucide-react";
import { editionLabel } from "../utils/dates";

const contents = [
  { page: "p. 3", text: "Où voir votre statut exact dans TikTok Studio, avec captures d'écran de l'application en français." },
  { page: "p. 5", text: "Les 7 critères que TikTok vérifie, expliqués en une phrase chacun." },
  { page: "p. 8", text: "Pourquoi vos vues « ne comptent pas », et le format de vidéo qui compte vraiment." },
  { page: "p. 11", text: "Comment lever l'effet des avertissements sans supprimer votre compte." },
  { page: "p. 14", text: "Compte personnel ou professionnel : lequel choisir, et comment changer en 2 minutes." },
  { page: "p. 16", text: "Ce que TikTok appelle « contenu non original » (reposts, sons, filigranes) et comment l'éviter." },
  { page: "p. 19", text: "La vérité sur les pays éligibles en Afrique, et ce qui est déjà possible chez vous : LIVE, marques locales, vente de vos produits." },
  { page: "p. 23", text: "Recevoir votre argent depuis le Bénin, la Côte d'Ivoire, le Sénégal, le Togo, le Cameroun… : options, frais, délais." },
  { page: "p. 27", text: "La checklist d'une page à cocher, semaine après semaine." },
];

const format = [
  { icon: FileText, t: "PDF de 28 pages, 4 Mo" },
  { icon: Smartphone, t: "Lisible sur Android et iPhone" },
  { icon: WifiOff, t: "Fonctionne hors ligne" },
  { icon: RefreshCw, t: "Nouvelle version gratuite à chaque changement des règles" },
];

export default function Guide() {
  return (
    <section id="contenu" className="relative py-20 sm:py-28 overflow-hidden scroll-mt-24">
      <div className="absolute inset-0 -z-10">
        <div className="blob bg-purple-600 w-[500px] h-[500px] top-20 -left-40 animate-float-slow opacity-30" />
        <div className="blob bg-[#25F4EE] w-[500px] h-[500px] bottom-20 -right-40 animate-float opacity-30" />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-[1fr_1.4fr] gap-10 lg:gap-16">
          <div className="lg:sticky lg:top-32 lg:self-start">
            <Reveal>
              <span className="inline-block text-xs uppercase tracking-[0.3em] text-[#25F4EE] mb-4">Dans le guide</span>
              <h2 className="text-4xl sm:text-5xl font-bold tracking-[-0.03em] mb-5">
                28 pages.
                <br />
                <span className="font-serif italic gradient-text">Zéro blabla.</span>
              </h2>
              <p className="text-lg text-white/60 mb-8 leading-relaxed">
                Ce n'est pas une formation, ni un accompagnement. C'est un guide clair, à lire en 40 minutes,
                à appliquer sur quelques semaines. Chaque point correspond à une ligne de votre écran d'éligibilité.
              </p>

              <ul className="space-y-3 mb-8">
                {format.map((f) => {
                  const Icon = f.icon;
                  return (
                    <li key={f.t} className="flex items-center gap-3 text-sm text-white/80">
                      <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#FE2C55]/20 to-[#25F4EE]/20 border border-white/10 flex items-center justify-center flex-shrink-0">
                        <Icon className="w-4 h-4 text-white" />
                      </span>
                      {f.t}
                    </li>
                  );
                })}
              </ul>

              <div className="text-xs text-white/40 mb-8">Édition {editionLabel()}</div>

              <a
                href="#prix"
                className="inline-flex items-center gap-2 bg-white text-black px-6 py-3.5 rounded-xl font-semibold hover:bg-white/90 transition-colors"
              >
                Recevoir le guide · 1 000 FCFA
                <ArrowRight className="w-4 h-4" />
              </a>
            </Reveal>
          </div>

          <ol className="space-y-3">
            {contents.map((c, i) => (
              <Reveal key={c.page} delay={i * 60}>
                <li className="group flex items-start gap-4 p-5 rounded-2xl glass hover:bg-white/[0.06] border border-white/10 hover:border-white/20 transition-all duration-500">
                  <span className="flex-shrink-0 min-w-[3.25rem] px-2 py-1.5 rounded-lg bg-gradient-to-br from-[#FE2C55] to-[#25F4EE] text-xs font-bold text-center tabular-nums">
                    {c.page}
                  </span>
                  <p className="text-[15px] text-white/85 leading-relaxed">{c.text}</p>
                </li>
              </Reveal>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
