import { useEffect, useState } from "react";
import { ArrowRight, Check, X, Smartphone, MessageCircle, FileText, ChevronLeft, BadgeCheck } from "lucide-react";
import { Reveal } from "./Reveal";

export default function Hero() {
  return (
    <section className="relative pt-32 sm:pt-40 pb-16 sm:pb-24 overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="blob bg-[#FE2C55] w-[600px] h-[600px] -top-40 -left-40 animate-float" />
        <div className="blob bg-[#25F4EE] w-[500px] h-[500px] top-40 -right-40 animate-float-slow" />
        <div className="blob bg-purple-600 w-[400px] h-[400px] bottom-0 left-1/3 animate-float-slow" />
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.4) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
            maskImage: "radial-gradient(ellipse at center, black 30%, transparent 75%)",
          }}
        />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-[1.15fr_0.85fr] gap-12 lg:gap-16 items-center">
          <div className="text-center lg:text-left">
            <Reveal>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-white/10 mb-6 text-xs sm:text-sm">
                <FileText className="w-3.5 h-3.5 text-[#25F4EE]" />
                <span className="text-white/80">Guide PDF · 28 pages · 🇧🇯 🇨🇮 🇸🇳 🇹🇬 🇨🇲 et toute l'Afrique francophone</span>
              </div>
            </Reveal>

            <Reveal delay={100}>
              <h1 className="text-[2.35rem] leading-[1.06] sm:text-5xl lg:text-6xl xl:text-7xl font-bold tracking-[-0.03em] mb-6">
                Vous postez. Vous faites des vues.
                <br />
                Et TikTok affiche toujours
                <br />
                <span className="font-serif italic font-normal gradient-text">« Non éligible ».</span>
              </h1>
            </Reveal>

            <Reveal delay={200}>
              <p className="text-lg sm:text-xl text-white/60 max-w-xl mx-auto lg:mx-0 leading-relaxed mb-8">
                Ce n'est pas de la malchance. C'est une liste de critères que personne ne vous a expliqués.
                Ce guide vous montre <span className="text-white font-medium">lesquels bloquent votre compte</span>{" "}
                et comment les corriger, un par un, depuis votre téléphone.
              </p>
            </Reveal>

            <Reveal delay={300}>
              <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start mb-8">
                <a
                  href="#prix"
                  className="group inline-flex items-center justify-center gap-2 bg-gradient-to-r from-[#FE2C55] to-[#FF4D7A] px-7 py-4 rounded-2xl font-semibold text-base btn-glow"
                >
                  Recevoir le guide · 1 000 FCFA
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </a>
                <a
                  href="#contenu"
                  className="inline-flex items-center justify-center gap-2 glass hover:bg-white/10 px-7 py-4 rounded-2xl font-semibold text-base transition-colors"
                >
                  Voir ce qu'il contient
                </a>
              </div>
            </Reveal>

            <Reveal delay={400}>
              <div className="flex flex-wrap justify-center lg:justify-start gap-x-6 gap-y-2 text-sm text-white/60">
                {[
                  { icon: Smartphone, t: "Paiement Mobile Money" },
                  { icon: MessageCircle, t: "Envoyé sur WhatsApp en 5 min" },
                  { icon: FileText, t: "Lisible hors ligne" },
                ].map(({ icon: Icon, t }) => (
                  <div key={t} className="flex items-center gap-2">
                    <Icon className="w-4 h-4 text-[#25F4EE]" strokeWidth={2.5} />
                    <span>{t}</span>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>

          <Reveal delay={300} className="relative">
            <EligibilityPhone />
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* Écran d'éligibilité : « aujourd'hui » → « après le guide » */

const CRITERIA = [
  { label: "Abonnés", before: "8 430 / 10 000", after: "10 250 / 10 000", okBefore: false },
  { label: "Vues qualifiées · 30 j", before: "22 000 / 100 000", after: "118 000 / 100 000", okBefore: false },
  { label: "Âge vérifié (18 ans et +)", before: "Vérifié", after: "Vérifié", okBefore: true },
  { label: "Compte en règle", before: "2 avertissements", after: "0 avertissement", okBefore: false },
  { label: "Contenu original", before: "Reposts détectés", after: "Validé", okBefore: false },
  { label: "Vidéos de 1 min et +", before: "9 % des vidéos", after: "82 % des vidéos", okBefore: false },
];

function EligibilityPhone() {
  const [after, setAfter] = useState(false);
  const [manual, setManual] = useState(false);

  useEffect(() => {
    if (manual) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const id = setInterval(() => setAfter((a) => !a), 4200);
    return () => clearInterval(id);
  }, [manual]);

  const okCount = CRITERIA.filter((c) => after || c.okBefore).length;
  const pct = Math.round((okCount / CRITERIA.length) * 100);
  const choose = (v: boolean) => {
    setManual(true);
    setAfter(v);
  };

  return (
    <div className="relative mx-auto w-full max-w-[380px]">
      <div className="absolute inset-0 -z-10 blur-3xl opacity-60">
        <div
          className={`absolute top-10 left-0 w-72 h-72 rounded-full transition-colors duration-1000 ${
            after ? "bg-emerald-500" : "bg-[#FE2C55]"
          }`}
        />
        <div className="absolute bottom-10 right-0 w-72 h-72 rounded-full bg-[#25F4EE]" />
      </div>

      <div className="relative mx-auto w-[300px] sm:w-[320px] rounded-[3rem] bg-gradient-to-b from-zinc-800 to-zinc-950 p-[3px] shadow-[0_50px_100px_-20px_rgba(254,44,85,0.35)]">
        <div className="relative w-full rounded-[2.8rem] bg-[#0B0B10] overflow-hidden">
          <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-full z-10" />

          <div className="pt-10 px-5 pb-2 flex items-center justify-between text-[11px] text-white/60">
            <span>9:41</span>
            <span className="flex gap-1 items-center">
              <span className="text-[9px]">4G</span>
              <span className="w-5 h-2.5 rounded-sm border border-white/50 relative">
                <span className="absolute inset-y-0 left-0 w-3/4 bg-white/70 rounded-sm" />
              </span>
            </span>
          </div>

          <div className="px-4 pb-3 flex items-center gap-2 text-xs text-white/70 border-b border-white/5">
            <ChevronLeft className="w-4 h-4" />
            <span className="truncate">TikTok Studio › Monétisation</span>
          </div>

          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-500 ${
                  after
                    ? "bg-emerald-500/15 text-emerald-300 border border-emerald-400/30"
                    : "bg-[#FE2C55]/15 text-[#FF6B8A] border border-[#FE2C55]/30"
                }`}
                aria-live="polite"
              >
                {after ? <BadgeCheck className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
                {after ? "Éligible" : "Non éligible"}
              </div>
              <div className="text-[11px] text-white/50 text-right leading-tight">
                312 000 vues
                <br />
                <span className="text-white/30">ces 30 derniers jours</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-white/50 mb-1">
                <span>Critères validés</span>
                <span className="tabular-nums">
                  {okCount}/{CRITERIA.length}
                </span>
              </div>
              <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-1000 ease-out ${
                    after ? "bg-gradient-to-r from-emerald-400 to-[#25F4EE]" : "bg-[#FE2C55]"
                  }`}
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>

            <ul className="space-y-1.5" aria-label="Critères d'éligibilité">
              {CRITERIA.map((c, i) => {
                const ok = after || c.okBefore;
                const delay = after ? `${i * 110}ms` : "0ms";
                return (
                  <li
                    key={c.label}
                    className={`flex items-center justify-between gap-2 rounded-xl px-3 py-2 border transition-all duration-500 ${
                      ok ? "bg-emerald-500/[0.07] border-emerald-400/20" : "bg-white/[0.03] border-white/5"
                    }`}
                    style={{ transitionDelay: delay }}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center transition-all duration-500 ${
                          ok ? "bg-emerald-400 text-black" : "bg-[#FE2C55]/20 text-[#FF6B8A]"
                        }`}
                        style={{ transitionDelay: delay }}
                      >
                        {ok ? <Check className="w-3 h-3" strokeWidth={3} /> : <X className="w-3 h-3" strokeWidth={3} />}
                      </span>
                      <span className="text-[12px] text-white/85 truncate">{c.label}</span>
                    </div>
                    <span className={`text-[11px] tabular-nums whitespace-nowrap ${ok ? "text-emerald-300" : "text-white/45"}`}>
                      {ok ? c.after : c.before}
                    </span>
                  </li>
                );
              })}
            </ul>

            <div
              className="grid grid-cols-2 p-1 rounded-xl bg-white/5 border border-white/10 text-[11px] font-medium"
              role="group"
              aria-label="Comparer avant et après"
            >
              <button
                onClick={() => choose(false)}
                aria-pressed={!after}
                className={`py-2 rounded-lg transition-all ${!after ? "bg-white text-black shadow" : "text-white/60 hover:text-white"}`}
              >
                Aujourd'hui
              </button>
              <button
                onClick={() => choose(true)}
                aria-pressed={after}
                className={`py-2 rounded-lg transition-all ${after ? "bg-white text-black shadow" : "text-white/60 hover:text-white"}`}
              >
                Après le guide
              </button>
            </div>
          </div>
        </div>
      </div>

      <div
        className={`absolute -right-2 sm:-right-6 top-24 glass-strong rounded-2xl p-3 shadow-2xl w-40 transition-all duration-700 ${
          !after ? "opacity-100 translate-y-0 rotate-[3deg]" : "opacity-0 -translate-y-3 pointer-events-none"
        }`}
        aria-hidden={after}
      >
        <div className="text-[10px] text-white/50 mb-1">Le problème</div>
        <div className="text-sm font-semibold leading-tight">Des vues… qui ne comptent pas.</div>
      </div>
      <div
        className={`absolute -left-2 sm:-left-8 bottom-14 glass-strong rounded-2xl p-3 shadow-2xl w-44 transition-all duration-700 ${
          after ? "opacity-100 translate-y-0 rotate-[-3deg]" : "opacity-0 translate-y-3 pointer-events-none"
        }`}
        aria-hidden={!after}
      >
        <div className="text-[10px] text-white/50 mb-1">Après correction</div>
        <div className="text-sm font-semibold leading-tight">Vous pouvez enfin postuler.</div>
      </div>
    </div>
  );
}
