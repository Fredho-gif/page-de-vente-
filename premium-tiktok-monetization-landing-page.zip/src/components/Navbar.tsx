import { useEffect, useState } from "react";
import { BadgeCheck, Menu, X, ArrowRight } from "lucide-react";

const links = [
  { href: "#contenu", label: "Dans le guide" },
  { href: "#avis", label: "Avis" },
  { href: "#prix", label: "Prix" },
  { href: "#faq", label: "FAQ" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${scrolled ? "py-3" : "py-5"}`}>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav
          aria-label="Navigation principale"
          className={`flex items-center justify-between rounded-2xl px-4 sm:px-6 py-3 transition-all duration-500 ${
            scrolled
              ? "bg-[#0A0A0F]/80 backdrop-blur-2xl border border-white/10 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.5)]"
              : "bg-transparent border border-transparent"
          }`}
        >
          <a href="#" className="flex items-center gap-2.5 group" aria-label="Guide Éligibilité TikTok — accueil">
            <div className="relative">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#FE2C55] via-[#FF4D7A] to-[#25F4EE] flex items-center justify-center shadow-lg shadow-[#FE2C55]/30">
                <BadgeCheck className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-[#FE2C55] to-[#25F4EE] blur-xl opacity-40 group-hover:opacity-60 transition-opacity" />
            </div>
            <div className="flex flex-col leading-none">
              <span className="font-bold text-[15px] tracking-tight">Guide Éligibilité</span>
              <span className="text-[10px] text-white/50 tracking-widest uppercase">TikTok · Afrique</span>
            </div>
          </a>

          <div className="hidden md:flex items-center gap-1">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="px-4 py-2 text-sm text-white/70 hover:text-white transition-colors relative group"
              >
                {l.label}
                <span className="absolute inset-x-4 -bottom-0.5 h-px bg-gradient-to-r from-transparent via-[#FE2C55] to-transparent scale-x-0 group-hover:scale-x-100 transition-transform origin-left" />
              </a>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <a
              href="#prix"
              className="hidden sm:inline-flex items-center gap-2 text-sm font-medium bg-gradient-to-r from-[#FE2C55] to-[#FF4D7A] hover:from-[#FF4D7A] hover:to-[#FE2C55] px-4 py-2.5 rounded-xl transition-all duration-300 shadow-lg shadow-[#FE2C55]/30 hover:shadow-[#FE2C55]/50 hover:-translate-y-0.5"
            >
              Recevoir le guide · 1 000 F
              <ArrowRight className="w-4 h-4" />
            </a>
            <button
              onClick={() => setOpen(!open)}
              className="md:hidden w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center"
              aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
              aria-expanded={open}
            >
              {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </nav>

        <div
          className={`md:hidden mt-2 overflow-hidden transition-all duration-500 ${
            open ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
          }`}
        >
          <div className="glass rounded-2xl p-4 flex flex-col gap-1">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="px-4 py-3 text-white/80 hover:text-white hover:bg-white/5 rounded-xl transition-colors"
              >
                {l.label}
              </a>
            ))}
            <a
              href="#prix"
              onClick={() => setOpen(false)}
              className="mt-2 text-center bg-gradient-to-r from-[#FE2C55] to-[#FF4D7A] px-4 py-3 rounded-xl font-medium"
            >
              Recevoir le guide · 1 000 FCFA
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
