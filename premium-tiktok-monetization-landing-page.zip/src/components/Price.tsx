import { Reveal } from "./Reveal";
import { Check, ArrowRight, ShieldCheck, MessageCircle, Clock } from "lucide-react";
import { editionLabel } from "../utils/dates";

const included = [
  "Le guide PDF de 28 pages",
  "La checklist d'une page à cocher",
  "La fiche « Recevoir mon argent » par pays",
  "Les nouvelles versions du guide, gratuitement",
];

const methods = [
  { name: "MTN MoMo", dot: "bg-[#FFCC00]" },
  { name: "Moov Money", dot: "bg-[#0066B3]" },
  { name: "Orange Money", dot: "bg-[#FF7900]" },
  { name: "Wave", dot: "bg-[#1DC3F0]" },
  { name: "Free Money", dot: "bg-[#CD1126]" },
];

export default function Price() {
  return (
    <section id="prix" className="relative py-20 sm:py-28 overflow-hidden scroll-mt-24">
      <div className="absolute inset-0 -z-10">
        <div className="blob bg-[#FE2C55] w-[500px] h-[500px] top-1/3 left-1/4 animate-float-slow opacity-20" />
        <div className="blob bg-[#25F4EE] w-[400px] h-[400px] top-1/2 right-1/4 animate-float opacity-20" />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="max-w-2xl mx-auto text-center mb-12">
            <span className="inline-block text-xs uppercase tracking-[0.3em] text-[#25F4EE] mb-4">Le prix</span>
            <h2 className="text-4xl sm:text-5xl font-bold tracking-[-0.03em] mb-4">
              Un seul prix.
              <br />
              <span className="font-serif italic gradient-text">Un seul paiement.</span>
            </h2>
            <p className="text-lg text-white/60">
              Moins cher qu'un forfait internet d'une journée. Pas d'abonnement, pas de « deuxième offre » après.
            </p>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="relative max-w-lg mx-auto p-8 sm:p-10 rounded-[2rem] bg-gradient-to-br from-[#FE2C55]/20 via-purple-500/10 to-[#25F4EE]/20 border border-[#FE2C55]/40 shadow-2xl shadow-[#FE2C55]/20">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2">
              <div className="px-4 py-1.5 rounded-full bg-gradient-to-r from-[#FE2C55] to-[#FF4D7A] text-xs font-bold tracking-wider uppercase shadow-lg whitespace-nowrap">
                Édition {editionLabel()}
              </div>
            </div>

            <div className="text-center mb-8">
              <h3 className="text-xl font-semibold text-white/80 mb-4">Le Guide Éligibilité TikTok</h3>
              <div className="flex items-baseline justify-center gap-2 mb-1">
                <span className="text-6xl sm:text-7xl font-bold tracking-[-0.04em]">1 000</span>
                <span className="text-2xl font-semibold text-white/70">FCFA</span>
              </div>
              <div className="text-sm text-white/50">paiement unique · accès immédiat</div>
            </div>

            <ul className="space-y-3 mb-8">
              {included.map((f) => (
                <li key={f} className="flex items-start gap-3 text-[15px]">
                  <span className="flex-shrink-0 w-5 h-5 rounded-full bg-[#25F4EE] flex items-center justify-center mt-0.5">
                    <Check className="w-3 h-3 text-black" strokeWidth={3} />
                  </span>
                  <span className="text-white/85">{f}</span>
                </li>
              ))}
            </ul>

            <a
              href="#"
              className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 rounded-2xl font-semibold text-base bg-gradient-to-r from-[#FE2C55] to-[#FF4D7A] hover:from-[#FF4D7A] hover:to-[#FE2C55] text-white btn-glow mb-5"
            >
              Payer 1 000 FCFA par Mobile Money
              <ArrowRight className="w-4 h-4" />
            </a>

            <div className="flex flex-wrap justify-center gap-2 mb-6" aria-label="Moyens de paiement acceptés">
              {methods.map((m) => (
                <span
                  key={m.name}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/25 border border-white/10 text-xs text-white/80"
                >
                  <span className={`w-2 h-2 rounded-full ${m.dot}`} aria-hidden="true" />
                  {m.name}
                </span>
              ))}
            </div>

            <ul className="space-y-2.5 text-sm text-white/70 border-t border-white/10 pt-6">
              <li className="flex items-start gap-2.5">
                <MessageCircle className="w-4 h-4 text-[#25F4EE] flex-shrink-0 mt-0.5" />
                <span>Lien envoyé sur WhatsApp et par e-mail dès confirmation, en général en moins de 5 minutes.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-[#25F4EE] flex-shrink-0 mt-0.5" />
                <span>7 jours pour le lire. S'il ne vous apprend rien : remboursé sur votre Mobile Money.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#25F4EE] flex-shrink-0 mt-0.5" />
                <span>Carte bancaire possible pour la diaspora.</span>
              </li>
            </ul>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
