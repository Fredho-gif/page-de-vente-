import { Reveal } from "./Reveal";
import { Clock, AlertTriangle, Copy, ArrowRight } from "lucide-react";

const stats = [
  { value: "2 300+", label: "guides envoyés depuis 2024" },
  { value: "12", label: "pays d'Afrique francophone" },
  { value: "34 j", label: "délai médian pour passer les critères au vert*" },
  { value: "4,7/5", label: "sur 214 avis reçus sur WhatsApp" },
];

const fixes = [
  { icon: Clock, before: "Vidéos de 15 secondes", after: "Vidéos de 1 min et + qui comptent" },
  { icon: AlertTriangle, before: "2 avertissements jamais vus", after: "Compte de nouveau en règle" },
  { icon: Copy, before: "Reposts et sons bloqués", after: "Contenu reconnu comme original" },
];

export default function Proof() {
  return (
    <section className="relative py-16 sm:py-24 border-y border-white/5">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="max-w-2xl mx-auto text-center mb-12">
            <span className="inline-block text-xs uppercase tracking-[0.3em] text-[#25F4EE] mb-4">Résultats</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-[-0.03em] mb-4">
              Le seul résultat qui compte se voit{" "}
              <span className="font-serif italic gradient-text">dans votre TikTok Studio.</span>
            </h2>
            <p className="text-lg text-white/60">
              Pas de logos de presse, pas de captures de virements. Juste des lignes rouges qui passent au vert.
            </p>
          </div>
        </Reveal>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 mb-3">
          {stats.map((s, i) => (
            <Reveal key={s.label} delay={i * 100}>
              <div className="text-center lg:text-left">
                <div className="text-4xl sm:text-5xl font-bold tracking-[-0.04em] gradient-text mb-2">{s.value}</div>
                <div className="text-sm text-white/50 leading-snug">{s.label}</div>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal delay={300}>
          <p className="text-xs text-white/35 text-center lg:text-left mb-12 max-w-3xl">
            *Médiane calculée sur 140 lecteurs qui nous ont envoyé une capture de leur écran d'éligibilité avant et
            après. Concerne les critères que vous contrôlez (avertissements, originalité, durée des vidéos, type de
            compte). Résultats individuels variables, non garantis.
          </p>
        </Reveal>

        <div className="grid sm:grid-cols-3 gap-4">
          {fixes.map((f, i) => {
            const Icon = f.icon;
            return (
              <Reveal key={f.before} delay={i * 80}>
                <div className="group relative p-5 rounded-3xl glass border border-white/10 hover:border-white/20 transition-all duration-500 overflow-hidden h-full">
                  <div className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-gradient-to-br from-[#FE2C55] to-[#25F4EE] opacity-0 group-hover:opacity-15 blur-3xl transition-opacity duration-700" />
                  <div className="relative flex items-start gap-4">
                    <div className="flex-shrink-0 w-11 h-11 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                      <Icon className="w-5 h-5 text-white/80" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm text-white/45 line-through decoration-[#FE2C55]/60 mb-1.5">{f.before}</div>
                      <div className="flex items-start gap-2 text-[15px] font-medium text-white">
                        <ArrowRight className="w-4 h-4 text-[#25F4EE] flex-shrink-0 mt-0.5" />
                        <span>{f.after}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
