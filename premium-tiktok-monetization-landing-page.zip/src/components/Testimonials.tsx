import { Reveal } from "./Reveal";
import { Star, Quote, MapPin } from "lucide-react";

const testimonials = [
  {
    name: "Rodrigue A.",
    city: "Cotonou, Bénin",
    niche: "Humour",
    avatar: "R",
    gradient: "from-[#FE2C55] to-orange-500",
    quote:
      "12 000 abonnés et toujours bloqué. Page 11 du guide : deux avertissements que je n'avais jamais vus. J'ai suivi les étapes, passé mes vidéos à plus d'une minute. 34 jours après, tout était au vert.",
    result: "Critères validés en 34 jours",
  },
  {
    name: "Aïcha K.",
    city: "Abidjan, Côte d'Ivoire",
    niche: "Cuisine",
    avatar: "A",
    gradient: "from-[#25F4EE] to-blue-500",
    quote:
      "Je faisais 200 000 vues par mois avec des vidéos de 20 secondes. Une page du guide m'a expliqué pourquoi ça ne comptait pas. J'ai changé le format : 26 jours plus tard, mon compte était éligible. Pour 1 000 F, franchement.",
    result: "Éligible en 26 jours",
  },
  {
    name: "Moussa D.",
    city: "Dakar, Sénégal",
    niche: "Football",
    avatar: "M",
    gradient: "from-emerald-400 to-teal-600",
    quote:
      "Mon compte était marqué « contenu non original » à cause des reposts de matchs. J'ai fait le ménage comme indiqué. Trois semaines plus tard l'avertissement avait disparu, et le LIVE s'est débloqué juste après.",
    result: "Avertissement levé en 3 semaines",
  },
];

export default function Testimonials() {
  return (
    <section id="avis" className="relative py-20 sm:py-28 scroll-mt-24">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="max-w-2xl mx-auto text-center mb-12">
            <span className="inline-block text-xs uppercase tracking-[0.3em] text-[#25F4EE] mb-4">Avis de lecteurs</span>
            <h2 className="text-4xl sm:text-5xl font-bold tracking-[-0.03em] mb-4">
              Ils voyaient « Non éligible ».
              <br />
              <span className="font-serif italic gradient-text">Voici ce qu'ils ont corrigé.</span>
            </h2>
          </div>
        </Reveal>

        <div className="grid md:grid-cols-3 gap-5">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 100}>
              <div className="h-full relative p-7 rounded-3xl glass border border-white/10 hover:border-white/20 transition-all duration-500 hover:-translate-y-1 flex flex-col">
                <Quote className="w-8 h-8 text-white/10 mb-3" />
                <div className="flex gap-0.5 mb-4" aria-label="5 étoiles sur 5">
                  {[...Array(5)].map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-white/80 leading-relaxed mb-6 flex-1 text-[15px]">« {t.quote} »</p>
                <span className="self-start inline-flex px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-400/20 text-xs font-medium text-emerald-300 mb-5">
                  ✓ {t.result}
                </span>
                <div className="flex items-center gap-3 pt-5 border-t border-white/10">
                  <div
                    className={`w-11 h-11 rounded-full bg-gradient-to-br ${t.gradient} flex items-center justify-center font-bold text-white flex-shrink-0`}
                    aria-hidden="true"
                  >
                    {t.avatar}
                  </div>
                  <div className="min-w-0">
                    <div className="font-semibold text-sm">{t.name}</div>
                    <div className="text-xs text-white/50 flex items-center gap-1">
                      <MapPin className="w-3 h-3 flex-shrink-0" />
                      <span className="truncate">{t.city} · {t.niche}</span>
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <p className="mt-8 text-xs text-white/35 text-center max-w-2xl mx-auto">
            Avis reçus sur WhatsApp, publiés avec l'accord des lecteurs. Résultats individuels, non garantis :
            ils dépendent de votre pays, de votre régularité et des règles de TikTok.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
