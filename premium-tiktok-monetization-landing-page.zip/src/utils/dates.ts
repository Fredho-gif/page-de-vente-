/** Année en cours, pour le copyright. */
export function currentYear() {
  return new Date().getFullYear();
}

/**
 * Libellé d'édition du guide, calculé à partir de la date réelle du visiteur.
 * Ex. « Octobre 2026 ». Évite toute date figée qui deviendrait incohérente.
 */
export function editionLabel(d: Date = new Date()) {
  const s = d.toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
  return s.charAt(0).toUpperCase() + s.slice(1);
}
